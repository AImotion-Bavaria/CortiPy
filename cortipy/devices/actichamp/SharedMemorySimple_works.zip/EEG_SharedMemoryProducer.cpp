#include <windows.h>
#include <iostream>
#include <vector>
#include <atomic>
#include <thread>
#include "SDK.h"                  
#include "RawDataHandlerExample.h" 

#define BUFFER_SIZE 1000    // adjust based on max expected samples
#define MAX_CHANNELS 43     // match your amplifier channels

bool isConnected = false;
float currentSamplingRate = 0.0f;

struct SharedBuffer {
    std::atomic<int> writeIndex;
    float data[BUFFER_SIZE][MAX_CHANNELS];
};

SharedBuffer* shm = nullptr;
CAmplifier amp;

void DataAcquisitionThread() {
    RawDataHandler rdh(amp);
    std::vector<std::vector<float>> vvfData;

    int res = amp.StartAcquisition(RM_NORMAL);
    if (res != AMP_OK) {
        std::cerr << "Failed to start acquisition: " << res << "\n";
        return;
    }

    while (true) {
        int nSamples = rdh.ParseRawData(amp, vvfData);
        if (nSamples > 0) {
            for (auto& sample : vvfData) {
                int idx = shm->writeIndex.load() % BUFFER_SIZE;
                for (int ch = 0; ch < MAX_CHANNELS; ++ch) {
                    shm->data[idx][ch] = sample[ch];
                }
                shm->writeIndex.fetch_add(1);
            }
            vvfData.clear();
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }

    amp.StopAcquisition();
}



int SelectAmpFamily()
{
    int nFamily = 1;
    int res = SetAmplifierFamily((AmplifierFamily)nFamily);
    if (res != AMP_OK) {
        std::cerr << "Error setting amplifier family: " << res << "\n";
    }
    return res;
}

int SearchForAmps()
{
    int nRes;
    char hwi[20];
    strcpy_s(hwi, "USB");
    std::string sHWDeviceAddress = "";

    std::cout << "Searching for devices...\n";
    
    nRes = EnumerateDevices(hwi, sizeof(hwi), (const char*)sHWDeviceAddress.data(), 0);
    std::cout << "Found " << nRes << " devices.\n";
    return nRes;
}

void ConnectToAmp(int nIdx)
{
    if (isConnected) amp.Close();
    int res = amp.Open(nIdx);
    if (res != AMP_OK) {
        std::cerr << "Error opening amplifier: " << res << "\n";
        exit(-1);
    }
    isConnected = true;
    std::cout << "Connected to amplifier at index " << nIdx << "\n";
}

void ChangeSampleRate(float targetFs)
{
    float fBaseRate, fSubSampleDiv;
    int nRes;

    PropertyRange<float> prAvailableBaseRates;
    PropertyRange<float> prAvailableSubDivisors;

    nRes = amp.GetPropertyRange(prAvailableBaseRates, DPROP_F32_BaseSampleRate);
    nRes = amp.GetPropertyRange(prAvailableSubDivisors, DPROP_F32_SubSampleDivisor);

    std::vector<float> possibleRates;
    std::vector<std::pair<float,float>> rateCombinations;

    for (int i=0;i<prAvailableBaseRates.ByteLength/sizeof(float);++i)
        for(int j=0;j<prAvailableSubDivisors.ByteLength/sizeof(float);++j)
        {
            float eff = prAvailableBaseRates.RangeArray[i] / prAvailableSubDivisors.RangeArray[j];
            possibleRates.push_back(eff);
            rateCombinations.emplace_back(prAvailableBaseRates.RangeArray[i], prAvailableSubDivisors.RangeArray[j]);
        }

    auto closestIt = std::min_element(possibleRates.begin(), possibleRates.end(),
                                      [targetFs](float a, float b){ return std::abs(a-targetFs)<std::abs(b-targetFs); });

    float closestFs = *closestIt;
    int idx = std::distance(possibleRates.begin(), closestIt);
    float selectedBaseRate = rateCombinations[idx].first;
    float selectedSubDiv = rateCombinations[idx].second;

    nRes = amp.SetProperty(selectedBaseRate, DPROP_F32_BaseSampleRate);
    nRes = amp.SetProperty(selectedSubDiv, DPROP_F32_SubSampleDivisor);

    currentSamplingRate = closestFs;
    std::cout << "Effective sampling rate set: " << closestFs << " Hz\n";
}

int main() {
    HANDLE hMapFile = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE,
                                        0, sizeof(SharedBuffer), "EEG_SharedMemory");
    if (!hMapFile) {
        std::cerr << "Failed to create shared memory\n";
        return -1;
    }

    shm = (SharedBuffer*)MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedBuffer));
    if (!shm) {
        std::cerr << "Failed to map shared memory\n";
        CloseHandle(hMapFile);
        return -1;
    }

    shm->writeIndex = 0;

    // --- Amplifier connection ---
    SelectAmpFamily();
    int nDevs = SearchForAmps();
    if (nDevs <= 0) return -1;

    ConnectToAmp(0);
    ChangeSampleRate(1000.0f);

    std::thread acquisitionThread(DataAcquisitionThread);

    std::cout << "Acquisition running. Press Enter to stop...\n";
    std::cin.get();

    acquisitionThread.detach();  // or implement a proper stop flag

    amp.Close();
    UnmapViewOfFile(shm);
    CloseHandle(hMapFile);

    return 0;
}
