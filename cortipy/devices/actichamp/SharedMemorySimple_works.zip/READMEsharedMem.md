# EEG Shared Memory Acquisition
%
This project allows real-time acquisition of EEG data from the Brain Products ActiCHamp amplifier using a shared memory interface.  
The data is written from a standalone C++ producer (`EEG_SharedMemoryProducer.exe`) and consumed in MATLAB without losses.
%
---
%
## How it works
1. **Producer (C++ executable)**  
   - Connects to the amplifier via the Brain Products AmplifierSDK.  
   - Sets the sample rate.  
   - Starts data acquisition.  
   - Writes EEG samples into a shared memory buffer named `EEG_SharedMemory`.
%
2. **Consumer (MATLAB script)**  
   - Opens the shared memory.  
   - Continuously reads new EEG samples.  
   - Concatenates them into a MATLAB matrix for analysis.
%
---
%
## Usage
%
### Step 1: Build the Producer
Compile once with MSVC (Developer Command Prompt):
```bash
cl /EHsc EEG_SharedMemoryProducer.cpp AmplifierSDK.lib /Fe:EEG_SharedMemoryProducer.exe
```
%
### Step 2: Run the Producer
Start acquisition:
```bash
EEG_SharedMemoryProducer.exe
```
Output will show:
```
Searching for devices...
Found 1 devices.
Connected to amplifier at index 0
Effective sampling rate set: 1000 Hz
Acquisition running. Press Enter to stop...
```
%
Leave this running while MATLAB connects.
%
### Step 3: Run the Consumer in MATLAB
mex ReadSharedMemory.cpp
Create a file `Test_sharedMem.m` with the following content:
%
```matlab
Test_sharedMem.m
bufferSize   = 100000;   must match C++ definition
numChannels  = 64;       must match C++ definition
%
Open shared memory
mm = memmapfile('EEG_SharedMemory.dat', ...
    'Format', { 'single', [numChannels bufferSize], 'data'; ...
                'int32',  [1 1], 'writeIndex' }, ...
    'Writable', false);
%
allData = [];
%
disp('Reading from shared memory... Press CTRL+C to stop.');
%
while true
    idx = mm.Data.writeIndex;
    if idx > 0
        Compute circular buffer index
        circIdx = mod(idx-1, bufferSize) + 1;
        tempData = mm.Data.data(:, circIdx);
        
        Append to MATLAB array
        allData = [allData tempData];
    else
        pause(0.001);
    end
end
```
%
Run it in MATLAB:
```matlab
Test_sharedMem
```
%
Stop it with **Ctrl+C** when you want to finish.
%
---
%
## Notes
- Default buffer size is `100000` samples × `64` channels. Adjust in `EEG_SharedMemoryProducer.cpp` if needed.
- For long recordings, consider saving chunks to disk instead of concatenating continuously to avoid running out of RAM.
- Stop the producer by pressing **Enter** in its console window.
%
---
%
## Files
- `EEG_SharedMemoryProducer.cpp` — C++ shared memory producer  
- `EEG_SharedMemoryProducer.exe` — compiled executable  
- `Test_sharedMem.m` — MATLAB consumer script  
