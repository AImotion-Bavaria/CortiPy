% Preallocate empty storage
allData = [];

while true
    tempData = ReadSharedMemory();  % [channels x newSamples]
    if ~isempty(tempData)
        % Append new samples along 2nd dimension (time)
        allData = [allData; tempData]; 
        fprintf('Now collected %d samples\n', size(allData, 1));
    end
    pause(0.5); % small delay
end
plot(allData(:,33))