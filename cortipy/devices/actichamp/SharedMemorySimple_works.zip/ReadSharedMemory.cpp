#include "mex.h"
#include <windows.h>
#include <atomic>

#define BUFFER_SIZE 1000
#define MAX_CHANNELS 43

struct SharedBuffer {
    std::atomic<int> writeIndex;
    float data[BUFFER_SIZE][MAX_CHANNELS];
};

static SharedBuffer* shm = nullptr;
static int lastReadIndex = 0;

void OpenSharedMemory() {
    if (shm) return;

    HANDLE hMapFile = OpenFileMapping(FILE_MAP_READ, FALSE, "EEG_SharedMemory");
    if (!hMapFile) {
        mexErrMsgIdAndTxt("ReadSharedMemory:OpenError", "Cannot open shared memory.");
    }

    shm = (SharedBuffer*)MapViewOfFile(hMapFile, FILE_MAP_READ, 0, 0, sizeof(SharedBuffer));
    if (!shm) {
        CloseHandle(hMapFile);
        mexErrMsgIdAndTxt("ReadSharedMemory:MapError", "Cannot map shared memory.");
    }
}

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {
    OpenSharedMemory();

    int writeIdx = shm->writeIndex.load(std::memory_order_acquire);
    int nNewSamples = writeIdx - lastReadIndex;
    if (nNewSamples <= 0) {
        plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
        return;
    }

    // Limit to buffer size
    if (nNewSamples > BUFFER_SIZE) {
        nNewSamples = BUFFER_SIZE;
        lastReadIndex = writeIdx - BUFFER_SIZE;
    }

    // MATLAB expects samples × channels (numSamples rows × numChannels columns)
    plhs[0] = mxCreateDoubleMatrix(nNewSamples, MAX_CHANNELS, mxREAL);
    double* outData = mxGetPr(plhs[0]);

    for (int i = 0; i < nNewSamples; ++i) {
        int idx = (lastReadIndex + i) % BUFFER_SIZE;
        for (int ch = 0; ch < MAX_CHANNELS; ++ch) {
            // Column-major: row + col*numRows
            outData[i + ch * nNewSamples] = static_cast<double>(shm->data[idx][ch]);
        }
    }

    lastReadIndex = writeIdx;
}
